﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Have to Complete Pragram");
            Console.ReadLine();
        }
    }

    class Program1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Have to Complete Pragramme1");
            Console.ReadLine();
        }
    }
}
